const express = require("express");
const https = require("https");

const app = express();


app.get("/", function(req, res){

	const url = "https://api.openweathermap.org/data/2.5/weather?q=London,uk&appid=9288b9d6ec5ac2cba2849ab02331af54&units=metri";

	https.get(url, function (response){


		console.log(response);
	})
	res.send("Server is up and running")	
})



app.listen(3000, function(){
	console.log("Server is running on port 3000.");
})